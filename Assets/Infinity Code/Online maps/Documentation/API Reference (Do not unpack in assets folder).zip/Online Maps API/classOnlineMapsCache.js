var classOnlineMapsCache =
[
    [ "CacheLocation", "classOnlineMapsCache.html#a240976dc26d9f6608dd73cce5224434d", [
      [ "persistentDataPath", "classOnlineMapsCache.html#a240976dc26d9f6608dd73cce5224434dac601806fb7b3910e612f35350dc7dab3", null ],
      [ "custom", "classOnlineMapsCache.html#a240976dc26d9f6608dd73cce5224434da8b9035807842a4e4dbe009f3f1478127", null ]
    ] ],
    [ "ClearAllCaches", "classOnlineMapsCache.html#a0db637e3e7e788a0c7f66f6f2b010af7", null ],
    [ "ClearFileCache", "classOnlineMapsCache.html#a204c2fc25ec04443df6176a11290cba2", null ],
    [ "ClearMemoryCache", "classOnlineMapsCache.html#afdf8eb2913f25146e06b802cda36cd72", null ],
    [ "GetFileCacheFolder", "classOnlineMapsCache.html#aa4bfe16bdb3861cfee77e409eb81b021", null ],
    [ "GetFileCacheSizeFast", "classOnlineMapsCache.html#ac1fe6f7291b4554f7cf9ed7e93c2dc03", null ],
    [ "GetFullTilePath", "classOnlineMapsCache.html#a526f4d4a3d793cd42d980da79e649a90", null ],
    [ "GetSavableItems", "classOnlineMapsCache.html#a873f7f21b6276e42a5ecfd6305687900", null ],
    [ "GetShortTilePath", "classOnlineMapsCache.html#a80df644f2bf3f7270656dedb14fc677b", null ],
    [ "fileCacheCustomPath", "classOnlineMapsCache.html#a110d06e7f2f43d47a587921c980d0c6d", null ],
    [ "fileCacheLocation", "classOnlineMapsCache.html#acbec0e56dfc43e25425b32c17c3e663d", null ],
    [ "fileCacheTilePath", "classOnlineMapsCache.html#acc8a4cc0b190e7783d17cb3288de1234", null ],
    [ "fileCacheUnloadRate", "classOnlineMapsCache.html#ab27389fc3c79d00674a6225c8c5485dc", null ],
    [ "maxFileCacheSize", "classOnlineMapsCache.html#a98802d4dd3f9ee9c99a10cc2fc891ff9", null ],
    [ "maxMemoryCacheSize", "classOnlineMapsCache.html#ad637de8c0e41d69c93bbc327069b9a8a", null ],
    [ "memoryCacheUnloadRate", "classOnlineMapsCache.html#adf0361f313ab2ee0251331b86f00e8be", null ],
    [ "OnLoadedFromCache", "classOnlineMapsCache.html#abf983ebbfba353d2355b953c8f31bd27", null ],
    [ "OnLoadedFromFileCache", "classOnlineMapsCache.html#a553744d7dea395deabe5288920e71b47", null ],
    [ "useFileCache", "classOnlineMapsCache.html#aa818cfb789063f02658414906e4dedc2", null ],
    [ "useMemoryCache", "classOnlineMapsCache.html#ad33c4d1f579d4904d473734072950f74", null ],
    [ "fileCacheSize", "classOnlineMapsCache.html#ae550c6742ead6469c09cb7b2d194e131", null ],
    [ "instance", "classOnlineMapsCache.html#ad68e5e5f7066ad27d1b591ecd3b4bab7", null ],
    [ "memoryCacheSize", "classOnlineMapsCache.html#a4c326866ac870c19746201e29740da43", null ]
];