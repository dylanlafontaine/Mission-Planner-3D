var classOnlineMapsGooglePlaceDetailsResult =
[
    [ "OnlineMapsGooglePlaceDetailsResult", "classOnlineMapsGooglePlaceDetailsResult.html#a8de00ae07e3a80311806f12b46411dfb", null ],
    [ "formatted_address", "classOnlineMapsGooglePlaceDetailsResult.html#aabd8bbe08371c6cbd9b17fbde722253b", null ],
    [ "formatted_phone_number", "classOnlineMapsGooglePlaceDetailsResult.html#ac4f3e56e0002817837d3510f1598abf7", null ],
    [ "icon", "classOnlineMapsGooglePlaceDetailsResult.html#aed3184bfa2ef292a3d67d833a11872d2", null ],
    [ "id", "classOnlineMapsGooglePlaceDetailsResult.html#a8c7eb602d79e6ccae431d4d6fbb483cc", null ],
    [ "international_phone_number", "classOnlineMapsGooglePlaceDetailsResult.html#a993eeb35e606a2afa87bc48003edf0c7", null ],
    [ "location", "classOnlineMapsGooglePlaceDetailsResult.html#aeb5d82a943d2128b499b5de448c0c912", null ],
    [ "name", "classOnlineMapsGooglePlaceDetailsResult.html#a7ec1bc99a7adc11e791eb0f98e47144a", null ],
    [ "node", "classOnlineMapsGooglePlaceDetailsResult.html#a8bd8bb076ea5f9898fb06d6313ca329f", null ],
    [ "photos", "classOnlineMapsGooglePlaceDetailsResult.html#abeb2542f10750b97ba090757034df3e2", null ],
    [ "place_id", "classOnlineMapsGooglePlaceDetailsResult.html#ad03d1ce8dc17acbaaca853ae5a38f55f", null ],
    [ "price_level", "classOnlineMapsGooglePlaceDetailsResult.html#afc7f2baf221fe18205077925e1f305d1", null ],
    [ "rating", "classOnlineMapsGooglePlaceDetailsResult.html#a189a82607acd5ea2c69e9a5119136503", null ],
    [ "reference", "classOnlineMapsGooglePlaceDetailsResult.html#a3d08912f6ec3da0870bf92195b8a085b", null ],
    [ "types", "classOnlineMapsGooglePlaceDetailsResult.html#a75f58c3bccc90e0519afe2210ccfa819", null ],
    [ "url", "classOnlineMapsGooglePlaceDetailsResult.html#a28b3963c2edecc58211bd1787a7b8c4d", null ],
    [ "utc_offset", "classOnlineMapsGooglePlaceDetailsResult.html#a558b0a3ed455d410c58557ea18f3a92a", null ],
    [ "vicinity", "classOnlineMapsGooglePlaceDetailsResult.html#aa01ffc26774693a608a1e57ca2ebe20e", null ],
    [ "website", "classOnlineMapsGooglePlaceDetailsResult.html#a5fbe0e4827cc74dd16ffd6e9f25d6ef1", null ]
];