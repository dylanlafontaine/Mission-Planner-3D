var classOnlineMapsGoogleDirectionsResult_1_1GeocodedWaypoint =
[
    [ "geocoder_status", "classOnlineMapsGoogleDirectionsResult_1_1GeocodedWaypoint.html#a5893ddb56a191e37287163b1c921417e", null ],
    [ "partial_match", "classOnlineMapsGoogleDirectionsResult_1_1GeocodedWaypoint.html#a93657287b3e0443ece543c184b7371d2", null ],
    [ "place_id", "classOnlineMapsGoogleDirectionsResult_1_1GeocodedWaypoint.html#a215a0ade1208909591192a64dd7c06aa", null ],
    [ "types", "classOnlineMapsGoogleDirectionsResult_1_1GeocodedWaypoint.html#a49214282eaca9c4ab74f1d8736ad283d", null ]
];